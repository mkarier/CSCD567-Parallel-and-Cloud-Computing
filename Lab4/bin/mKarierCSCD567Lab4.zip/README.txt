normal compile javac *.java

to run 
java MyLab4 numberOfThreads
