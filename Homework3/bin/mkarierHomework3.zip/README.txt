to compile 'javac *.java'

to run 'java ParallelSearchCoarse file pattern'

It doesn't seem to find all the patterns as it does for the serial method 
however it is very close. 
