To Run:
java MainWindow
