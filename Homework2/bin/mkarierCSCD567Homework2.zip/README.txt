to compile 'javac edu/ewu/ytian/prime/*.java'
to run 'java ewu.ewu.ytian.prime.MyPrimeTest numThreads lowest Highest'

